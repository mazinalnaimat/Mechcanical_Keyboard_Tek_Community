﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Tek_Mechanical_Keyboard.UI.Pages.Layers.Controls
{
    public class LayerModel
    {
        public int Index { get; set; }
        public string Name { get; set; }
    }

    public partial class LayerStackControl : UserControl
    {
        public ObservableCollection<LayerModel> Layers { get; set; }

        public LayerStackControl()
        {
            InitializeComponent();

            Layers = new ObservableCollection<LayerModel>
            {
                new LayerModel { Index = 0, Name = "Base Layer" },
                new LayerModel { Index = 1, Name = "Fn Layer" },
                new LayerModel { Index = 2, Name = "Navigation Layer" },
                new LayerModel { Index = 3, Name = "Symbols Layer" },
                new LayerModel { Index = 4, Name = "Media Layer" }
            };

            LayersListBox.ItemsSource = Layers;
        }

        private void LayerItem_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                Border border = sender as Border;
                if (border != null && border.DataContext is LayerModel draggedItem)
                {
                    DragDrop.DoDragDrop(border, draggedItem, DragDropEffects.Move);
                }
            }
        }

        private void LayersListBox_Drop(object sender, DragEventArgs e)
        {
            LayerModel droppedData = e.Data.GetData(typeof(LayerModel)) as LayerModel;
            if (droppedData == null) return;

            UIElement targetElement = e.OriginalSource as UIElement;
            ListBoxItem targetItem = GetParentListBoxItem(targetElement);

            int oldIndex = Layers.IndexOf(droppedData);
            int newIndex = oldIndex;

            if (targetItem != null && targetItem.DataContext is LayerModel targetData)
            {
                newIndex = Layers.IndexOf(targetData);
            }
            else
            {
                newIndex = Layers.Count - 1;
            }

            if (oldIndex != newIndex && oldIndex >= 0 && newIndex >= 0)
            {
                Layers.Move(oldIndex, newIndex);
                UpdateLayerIndexes();
            }
        }

        private void UpdateLayerIndexes()
        {
            for (int i = 0; i < Layers.Count; i++)
            {
                Layers[i].Index = i;
            }
            LayersListBox.Items.Refresh();
        }

        private ListBoxItem GetParentListBoxItem(UIElement element)
        {
            while (element != null && !(element is ListBoxItem))
            {
                element = VisualTreeHelper.GetParent(element) as UIElement;
            }
            return element as ListBoxItem;
        }

        private void AddLayerBtn_Click(object sender, RoutedEventArgs e)
        {
            int newIndex = Layers.Count;
            Layers.Add(new LayerModel { Index = newIndex, Name = $"New Layer {newIndex}" });
        }
    }
}